import java.lang.reflect.*;

public class Router {

    public static String dispatch(Container c, String path) {

        for (Object bean : c.getBeans()) {

            Class<?> clazz = bean.getClass();

            Method[] methods = clazz.getDeclaredMethods();

            for (Method method : methods) {

                Route route = method.getAnnotation(Route.class);

                if (route != null && route.path().equals(path)) {

                    try {

                        method.setAccessible(true);

                        return (String) method.invoke(bean);

                    } catch (Exception e) {

                        throw new RuntimeException(e);

                    }
                }
            }
        }

        return "404 Not Found: " + path;
    }
}
