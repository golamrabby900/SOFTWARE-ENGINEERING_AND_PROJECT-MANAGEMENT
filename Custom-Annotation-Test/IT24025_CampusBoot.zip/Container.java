import java.lang.reflect.*;
import java.util.*;

public class Container {

    private Map<String, Object> beans = new LinkedHashMap<>();

    // Part 1: Scan and Register Components
    public void scan(Class<?>... classes) {

        for (Class<?> clazz : classes) {

            Component component = clazz.getAnnotation(Component.class);

            if (component != null) {

                try {

                    String beanName = component.value();

                    if (beanName.isEmpty()) {
                        beanName = Character.toLowerCase(
                                clazz.getSimpleName().charAt(0))
                                + clazz.getSimpleName().substring(1);
                    }

                    Constructor<?> constructor =
                            clazz.getDeclaredConstructor();

                    constructor.setAccessible(true);

                    Object instance = constructor.newInstance();

                    beans.put(beanName, instance);

                    System.out.println("[Container] Registered: "
                            + beanName + " (" + clazz.getSimpleName() + ")");

                } catch (Exception e) {
                    throw new RuntimeException(e);
                }

            } else {

                System.out.println("[Container] Skipped: "
                        + clazz.getSimpleName() + " (no @Component)");

            }
        }
    }

    // Part 2: Inject Configuration Values
    public void injectValues(Map<String, String> config) {

        for (Object bean : beans.values()) {

            Class<?> clazz = bean.getClass();

            Field[] fields = clazz.getDeclaredFields();

            for (Field field : fields) {

                Value valueAnnotation =
                        field.getAnnotation(Value.class);

                if (valueAnnotation != null) {

                    String key = valueAnnotation.value();

                    String configValue = config.get(key);

                    if (configValue == null) {
                        throw new IllegalArgumentException(
                                "Missing configuration: " + key);
                    }

                    try {

                        field.setAccessible(true);

                        if (field.getType() == String.class) {

                            field.set(bean, configValue);

                        } else if (field.getType() == int.class) {

                            field.setInt(bean,
                                    Integer.parseInt(configValue));

                        } else {
                            throw new IllegalArgumentException(
                                    "Unsupported field type: "
                                            + field.getType());
                        }

                        System.out.println("[Container] Injected: "
                                + key + " -> "
                                + clazz.getSimpleName()
                                + "." + field.getName());

                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }
    }

    // Part 3: Get Bean
    public Object getBean(String name) {

        return beans.get(name);

    }

    // Helper method for Router
    public Collection<Object> getBeans() {

        return beans.values();

    }
}
