public class ReportPrinter {

}
