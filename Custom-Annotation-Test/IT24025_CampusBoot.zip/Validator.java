import java.lang.reflect.*;
import java.util.*;

public class Validator {

    public static List<String> validate(Object obj) {

        List<String> errors = new ArrayList<>();

        Class<?> clazz = obj.getClass();

        Field[] fields = clazz.getDeclaredFields();

        for (Field field : fields) {

            Range range = field.getAnnotation(Range.class);

            if (range != null && field.getType() == int.class) {

                try {

                    field.setAccessible(true);

                    int actualValue = field.getInt(obj);

                    if (actualValue < range.min()
                            || actualValue > range.max()) {

                        String message = field.getName()
                                + " - " + range.message()
                                + " (actual: " + actualValue + ")";

                        errors.add(message);
                    }

                } catch (IllegalAccessException e) {

                    throw new RuntimeException(e);

                }
            }
        }

        return errors;
    }
}
